/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desain_mobil;

import java.awt.*;
/**
 *
 * @author RECKY
 */
public class Desain_Mobil extends Panel{
    
    Desain_Mobil(){
        setBackground(Color.white);
    }
    
    public void paint(Graphics g) {
        int[] x = {30, 165, 165, 245, 245, 30};
        int[] y = {30, 30, 70, 70, 130, 130};
        g.setColor(new Color(51, 153, 255));
        Polygon pol = new Polygon(x, y, 6);
        g.fillPolygon(pol);
        
        //roda
        g.setColor(Color.red);
        g.fillOval(40, 100, 80, 70);
        g.fillOval(140, 100, 80, 70);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame f = new Frame("Desain Mobil");
        Desain_Mobil dm = new Desain_Mobil();
        f.add(dm);
        f.setSize(480, 300);
        f.setVisible(true);
    }
    
}
